drop table T_TEST if exists;

create table T_TEST (NAME varchar(50) not null);